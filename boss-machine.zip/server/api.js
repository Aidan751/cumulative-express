const express = require('express');
const apiRouter = express.Router();



module.exports = apiRouter;
